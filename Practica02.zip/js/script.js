// 1️. Afegir un nou <li> dinàmicament en clicar el botó Afegir Element.
/*document.querySelector('#afegirElement').addEventListener('click', function () {
    let nouElement = document.createElement('li');

    nouElement.textContent = "Nou Element";

    let llista = document.querySelector('ul');

    llista.appendChild(nouElement);
})*/
// 2️. No permetre afegir elements buits (cal validar l’input)
/*document.querySelector('#afegirElement').addEventListener('click', function () {
    let inputText = document.querySelector('#textElement').value.trim();

    // Validación del input
    if (inputText !== '') {
        let nouElement = document.createElement('li');
        nouElement.textContent = inputText;
        let llista = document.querySelector('#llistaElements');
        llista.appendChild(nouElement);
        document.querySelector('#textElement').value = ''; 
    } else {
       
        alert("No es pot afegir un element buit!");
    }
});
*/

// 3️. Cada element de la llista ha de contenir un text editable.
/*document.querySelector('#afegirElement').addEventListener('click', function () {
    let inputText = document.querySelector('#textElement').value.trim();

    // Validación del input
    if (inputText !== '') {
        let nouElement = document.createElement('li');
       
        //Crear un elemento span para el texto editable 
        let textSpan = document.createElement('span');
        textSpan.textContent = inputText;
        textSpan.contentEditable = true

        //Añadir el span al elemento 'li'
        nouElement.appendChild(textSpan);

        let llista = document.querySelector('#llistaElements');
        llista.appendChild(nouElement);
        document.querySelector('#textElement').value = ''; 
    } else {
       
        alert("No es pot afegir un element buit!");
    }
});
*/
// 4️. Cada element ha de tenir un botó "Editar" que activi la edició en línia.
/*document.querySelector('#afegirElement').addEventListener('click', function () {
    let inputText = document.querySelector('#textElement').value.trim();

    // Validación del input
    if (inputText !== '') {
        let nouElement = document.createElement('li');

        //Crear un elemento span para el texto editable 
        let textSpan = document.createElement('span');
        textSpan.textContent = inputText;
        textSpan.contentEditable = false //para que no se pueda editar siempre 

        //boton
        let editButton = document.createElement('button');
        editButton.textContent = 'Editar';
        editButton.addEventListener('click', function() { // esto revisa si el texto esta siendo editado para que salga el botón de guardar o editar 
            if (textSpan.contentEditable === 'true') {
                textSpan.contentEditable = 'false';
                editButton.textContent = 'Editar';
            } else {
                textSpan.contentEditable = 'true';
                textSpan.focus();
                editButton.textContent = 'Guardar';
            }
        })

        //Añadir el span y botón al elemento 'li' 
        nouElement.appendChild(textSpan);
        nouElement.appendChild(editButton);

        let llista = document.querySelector('#llistaElements');
        llista.appendChild(nouElement);
        document.querySelector('#textElement').value = ''; 
    } else {
       
        alert("No es pot afegir un element buit!");
    }
});
*/
// 5️. El text ha de canviar de color cada vegada que es faci clic sobre ell.
/*document.querySelector('#afegirElement').addEventListener('click', function () {
    let inputText = document.querySelector('#textElement').value.trim();

    if (inputText !== '') {
        let nouElement = document.createElement('li');

        let textSpan = document.createElement('span');
        textSpan.textContent = inputText;
        textSpan.contentEditable = false;
        textSpan.style.cursor = 'pointer'; // Añadir cursor pointer para indicar que es clickeable

        // Array de colores
        const colors = ['black', 'red', 'blue', 'green', 'purple', 'orange'];
        let colorIndex = 0;

        // Añadir evento de clic al texto para cambiar el color
        textSpan.addEventListener('click', function(event) {
            if (this.contentEditable !== 'true') {
                this.style.color = colors[colorIndex];
                colorIndex = (colorIndex + 1) % colors.length;
                console.log('Color changed to:', this.style.color); // Para depuración
            }
            event.stopPropagation();
        });

        let editButton = document.createElement('button');
        editButton.textContent = 'Editar';
        editButton.addEventListener('click', function(event) {
            if (textSpan.contentEditable === 'true') {
                textSpan.contentEditable = 'false';
                editButton.textContent = 'Editar';
            } else {
                textSpan.contentEditable = 'true';
                textSpan.focus();
                editButton.textContent = 'Guardar';
            }
            event.stopPropagation();
        });

        nouElement.appendChild(textSpan);
        nouElement.appendChild(editButton);

        let llista = document.querySelector('#llistaElements');
        llista.appendChild(nouElement);
        document.querySelector('#textElement').value = ''; 
    } else {
        alert("No es pot afegir un element buit!");
    }
});


*/
// 6️. El botó "Eliminar" ha de permetre eliminar l’element.
/*document.querySelector('#afegirElement').addEventListener('click', function () {
    let inputText = document.querySelector('#textElement').value.trim();

    if (inputText !== '') {
        let nouElement = document.createElement('li');

        let textSpan = document.createElement('span');
        textSpan.textContent = inputText;
        textSpan.contentEditable = false;
        textSpan.style.cursor = 'pointer'; // Añadir cursor pointer para indicar que es clickeable

        // Array de colores
        const colors = ['black', 'red', 'blue', 'green', 'purple', 'orange'];
        let colorIndex = 0;

        // Añadir evento de clic al texto para cambiar el color
        textSpan.addEventListener('click', function(event) {
            if (this.contentEditable !== 'true') {
                this.style.color = colors[colorIndex];
                colorIndex = (colorIndex + 1) % colors.length;
                console.log('Color changed to:', this.style.color); // Para depuración
            }
            event.stopPropagation();
        });

        let editButton = document.createElement('button');
        editButton.textContent = 'Editar';
        editButton.addEventListener('click', function(event) {
            if (textSpan.contentEditable === 'true') {
                textSpan.contentEditable = 'false';
                editButton.textContent = 'Editar';
            } else {
                textSpan.contentEditable = 'true';
                textSpan.focus();
                editButton.textContent = 'Guardar';
            }
            event.stopPropagation();
        });

        // Boton eliminar
        let eliButton = document.createElement('button'); 
        eliButton.textContent = 'Eliminar';
        eliButton.addEventListener('click', function() {
        nouElement.remove();
        });

        nouElement.appendChild(textSpan);
        nouElement.appendChild(editButton);
        nouElement.appendChild(eliButton); 


        let llista = document.querySelector('#llistaElements');
        llista.appendChild(nouElement);
        document.querySelector('#textElement').value = ''; 
    } else {
        alert("No es pot afegir un element buit!");
    }
});
*/
// 7️. El text editable s’ha de desactivar quan l'usuari guardi els canvis.
document.querySelector('#afegirElement').addEventListener('click', function () {
    let inputText = document.querySelector('#textElement').value.trim();

    if (inputText !== '') {
        let nouElement = document.createElement('li');

        let textSpan = document.createElement('span');
        textSpan.textContent = inputText;
        textSpan.contentEditable = false;
        textSpan.style.cursor = 'pointer'; // Añadir cursor pointer para indicar que es clickeable

        // Array de colores
        const colors = ['black', 'red', 'blue', 'green', 'purple', 'orange'];
        let colorIndex = 0;

        // Añadir evento de clic al texto para cambiar el color
        textSpan.addEventListener('click', function(event) {
            if (this.contentEditable !== 'true') {
                this.style.color = colors[colorIndex];
                colorIndex = (colorIndex + 1) % colors.length;
                console.log('Color changed to:', this.style.color); // Para depuración
            }
            event.stopPropagation();
        });

        let editButton = document.createElement('button');
        editButton.textContent = 'Editar';
        editButton.addEventListener('click', function(event) {
            if (textSpan.contentEditable === 'true') {
                textSpan.contentEditable = 'false';
                editButton.textContent = 'Editar';
            } else {
                textSpan.contentEditable = 'true';
                textSpan.focus();
                editButton.textContent = 'Guardar';
            }
            event.stopPropagation();
        });

        // Boton eliminar
        let eliButton = document.createElement('button'); 
        eliButton.textContent = 'Eliminar';
        eliButton.addEventListener('click', function() {
        nouElement.remove();
        });

        nouElement.appendChild(textSpan);
        nouElement.appendChild(editButton);
        nouElement.appendChild(eliButton); 


        let llista = document.querySelector('#llistaElements');
        llista.appendChild(nouElement);
        document.querySelector('#textElement').value = ''; 
    } else {
        alert("No es pot afegir un element buit!");
    }
});
