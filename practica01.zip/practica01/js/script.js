/*---------------------Part1---------------------------------------*/

const titol = document.querySelector('h1#titol');
const paragraf = document.querySelector('.paragraf');


//------------------------------------------------------------------

document.querySelector('h1').textContent = 'Mambelroy';

document.querySelector('p').style.fontWeight = 'bold';

/*document.querySelector('h1').style.fontWeight = 'normal';*/

//------------------------------------------------------------------

document.querySelector('h1').style.color = '#ff00ff';

document.querySelector('h1').style.fontSize = '75px';  

/*---------------------Part2---------------------------------------*/

document.querySelector('#canviarText').addEventListener('click', function() {
    document.querySelector(`h1`).textContent = 'yorlebmaM';
    document.querySelector(`p`).style.color = '#00ff00';
})


/*---------------------Part3---------------------------------------*/


document.querySelector('#afegirElement').addEventListener('click', function() {
    // crear un nou element
    const nouElemnt = document.createElement('li');

    //afegir el text a l'element
    nouElemnt.textContent = "Nou element afegit!";

    //obtener la llista 
    const llista = document.querySelector('#llista');

    //afegir el nou element a la llista 
    llista.appendChild(nouElemnt);
});

//------------------------------------------------------------------

document.querySelector('#eliminarElement').addEventListener('click', function() {
    const llista = document.querySelector('#llista');
   //aixo es per que si els 'children' son menys de 0 no borri rés i és pugi fer servir el botó anterior de afegir un 'child'
    if (llista.children.length > 0) {
        llista.removeChild(llista.lastElementChild);
    }
    //i aquesta part especifica que nomes elimini la ultima que s'ha fet 
});


